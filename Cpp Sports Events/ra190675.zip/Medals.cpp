#include "Medals.h"

Medal::Medal()
{
}
